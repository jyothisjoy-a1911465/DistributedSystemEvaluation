# Distributed Systems Assignment 2
**Student:** Chrislyne Pathrose (a1938588)

## Content Server
The Content Server is responsible for transmitting weather data to another server through a socket connection. It reads weather data from a specified feed file, converts it to JSON format, and sends it to the target server using HTTP PUT requests. The class includes retry logic for connection failures and tracks the last active time for each socket.

### Key Features
- Converts weather data from a feed file into JSON format. 
- Retries sending data in case of transmission failures. 
- Responds with appropriate HTTP status codes based on the success or failure of the data transfer.

## Aggregation Server
The Aggregation Server serves as a receiver for data from multiple content servers, managing client connections and processing requests. It is designed to aggregate and manage the weather data provided by these content servers.

### Key Features 
- Centralizes the collection of weather data from various sources.
- Concurrently manages incoming client connections to ensure data integrity.
- Organizes and stores weather data in the data/ directory.
- Automatically purges outdated data (data from old sockets or data not received in the last 20 messages) to maintain accuracy.
- Processes GET and PUT requests to facilitate data retrieval and submission. -Provides detailed error messages and status codes.

## GET Client
The GETClient is an application that retrieves weather data from the aggregation server. It sends HTTP GET requests and processes the server's responses. The GET Client will return only the weather data received in the last 30 seconds.

### Key Features 
- Sends HTTP GET requests to a content server for retrieving weather data.
- Implements a heartbeat mechanism to maintain an active connection with the server.
- Uses a Lamport clock to timestamp requests, ensuring correct ordering.
- Processes and formats server responses for improved readability.

------------------------------------------------------------------------------------------------------------------------------------------------
## Running in Eclipse
### To run the project in Eclipse, follow these steps:

Prerequisites
- Ensure you have the Java Development Kit (JDK) installed. 
- Place the JSON library in a lib folder within your project directory.
- Importing the Project Open Eclipse and select File > Import. 
- Choose Existing Projects into Workspace and click Next. 
- Browse to the location of your project and select it, then click Finish.
- Compile and Run the Programs

## Aggregation Server

- Open the AggregationServer.java file. 
- Right-click on the file in the Package Explorer and select Run As > Java Application. 
- Provide the port number as an argument in the run configuration: Click on Run > Run Configurations...
-  Select Java Application for your AggregationServer. 
- In the Arguments tab, add: http://localhost:4567
- Click Apply and then Run.
- Ensure that the Aggregation Server is running before starting the Content Server or GET Client.


## Content Server

- Open the ContentServer.java file.
-  Right-click on the file in the Package Explorer and select Run As > Java Application. 
- Provide the necessary arguments in the run configuration: Click on Run > Run Configurations... 
- Select Java Application on the left, then select your ContentServer.
- In the Arguments tab, add: http://localhost:4567 data.txt.
- Click Apply and then Run.

## GET Client 

- Open the GETClient.java file. 
- Right-click on the file in the Package Explorer and select Run As > Java Application. 
- In the run configuration, provide the server URL as an argument: Click on Run > Run Configurations... 
- Select Java Application for your GETClient. 
- In the Arguments tab, add: http://localhost:4567 .
- Click Apply and then Run.


## Running Test Cases in Eclipse
- Right click on the test classes(AggregationServerTest.java, ContentServerTest.java and GETClientTest.java) in the Package Explorer.
- Select Run as>JUnit Test.
- The JUnit view will show the results of the tests.

# Running the Project using Command Line

Directory Structure :: 
src/main/com/weather/app/

## Building the Project
1.	Navigate to the root directory of the project.
2.	Compile the Java files:
`javac -d bin src/main/com/weather/app/*.java`

## Running the Servers and Clients
1. Start the Aggregation Server
- Open a terminal and run the following command to start the Aggregation Server:
`java -cp bin com.weather.app.AggregationServer <server-address:port>`

Usage:
`java -cp bin com.weather.app.AggregationServer`

2. Start the Content Server
- In a new terminal, run the following command to start the Content Server. Replace <server-address:port> with the address and port of the Aggregation Server, and provide the path to the weather data file.
`java -cp bin com.weather.app.ContentServer <server-address:port> <file-path>`

Usage:
`java -cp bin com.weather.app.ContentServer localhost:4567 txt.txt`

3. Run the GET Client
- In another terminal, run the GET Client with the server address and port. Optionally, you can specify a station ID.
`java -cp bin com.weather.app.GETClient <server-address:port> [station-id]`

Usage:
`java -cp bin com.weather.app.GETClient localhost:4567`

# Step by Step Development Process

1. System Architecture Design:
  - Created a design diagram of the system architecture using draw.io.
2. Initial Configuration:
  - Developed a foundational weather application with preset input values in the content server.
  - Updated the aggregation server and initiated GET requests from the client.
  - This phase was crucial for grasping the workings of GET and PUT requests and understanding client-server interactions through sockets.
3. Data Upload Attempt:
  - Tried uploading data from the default JSON file in the content server to the aggregation server.
4. Code Adjustments:
  - Altered the content server code to display the PUT message as required.
  - Modified the aggregation server to read both headers and JSON data, storing it within the handlePUT request function.
5. Intermediate Storage Setup:
  - Enhanced the aggregation server to generate a temporary storage file, which helps the server remain functional during crashes.
  - Data is now saved in a temporary file, verified, and subsequently transferred to the permanent data file.
6. Response Code Implementation:
  - Improved the aggregation server's code to return success and failure response codes during operations.
7. Port Settings:
  - Established a default port number (4567) for the aggregation server.
  - Incorporated functionality to specify a custom port number via command-line arguments.
8. Data Management Strategy:
  - Configured the aggregation server to automatically delete any entries in the JSON that have not interacted with the server for 30 seconds.
  - Employed a HashMap to maintain the file along with associated data and timestamps, facilitating the conversion of weather data back to JSON format upon receiving a GET request.
9. Enhancements to GET Client:
  - Adjusted the GET client code to allow the use of a custom port number through command-line arguments.
  - The client now has the capability to strip the JSON formatting from the data received from the aggregation server and display it in a plain text format.
10. Timestamping and Ordering Mechanism:
  - Integrated a Lamport clock to timestamp requests, ensuring proper ordering of events.
  - Enhanced the formatting and processing of server responses to improve readability.
11. Testing Procedures:
  - Implemented JUnit test cases for all components of the code to verify functionality and reliability.
12. Code Annotations:
  - Included comments throughout the code to facilitate understanding and ease of maintenance.


## REFERENCE

1. Lamport, L. (1978). "Time, Clocks, and the Ordering of Events in a Distributed System," Communications of the ACM, 21(7), 558-565.
2. Tanenbaum, A.S. and Van Steen, M., 2007. Distributed Systems: Principles and Paradigms. 2nd ed. Upper Saddle River, NJ: Prentice Hall.
3. Van Renesse, R. and Birman, K., 1996. A formal approach to reasoning about time and clocks in distributed systems. Journal of Distributed Computing, [online] 9(4), pp.259–270.
4. ChatGPT for understanding how GET and PUT requests work, converting text to json, how to run code on Maven Eclipse, understanding lamport clocks, general guidance on implementing and applying code solutions, refining the comments in the code.
